<?php
	
/*
Plugin Name: PtbT Team Management
Plugin URi: http://pickthebestteam.com/team-management/
Description: <strong>Pick the Best Team Management</strong> plugin allows you to create teams and manage players through Wordpress. Add teams, players (junior & senior), track attendence, set up events, track stats. Build a better overview of which players are putting in the work and make you selection choices easier with quality information. <strong>This plugin adds a team management features to Pick the Best Team</strong>.
Version: 0.1
Author: Pick the Best Team
Author URi: pickthebestteam.com
License: GPL2
License URi: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: pick-the-best-team
*/

/* ! 0. TABLE OF CONTENTS */

/*
	1. HOOKS
	
	2. SHORTCODES
	
	3. FILTERS
	
	4. EXTERNAL SCRIPTS
	
	5. ACTIONS
	
	6. HELPERS
	
	7. CUSTOM POST TYPES
	
	8. ADMIN PAGES
	
	9. SETTINGS
	
*/

/* !1 HOOKS */
	
	// 1.0 hint: returns a html string for our ptbt team management form
	function ptbt_team_management_form_shortcode( $args, $content="") {
		
		// hint: get the list id
		$list_id = 0;
		if( isset($args['id']) ) $list_id = (int)$args['id'];
		
		// title
		$title = '';
		if( isset($args['title']) ) $title = (string)$args['title'];
		
		// setup our output variable - the form html
		$output = '
		
			<div class="ptbt">
									
				<form id="ptbt_register_form" name="ptbt_form" role="form" class="option1form ptbt-form" action="/wp-admin/admin-ajax.php?action=ptbt_save_subscription" method="post"> 
				    <div class="row">
				    
					    <input type="hidden" name="ptbt_list" value="'. $list_id .'">';
					    
					    
					    /* if( strlen($title) ):
					    
						    $output .= '<h3 class="ptbt_list">'. $title .'</h3>';
						    
					    endif; */
					    
					    
					    $output .= '<div class="col-md-6">
						    <div class="form-group"> 
						        <label class="control-label" for="ptbt_fname">First Name</label>
						        <input type="text" class="form-control" id="ptbt_fname" name="ptbt_fname" placeholder="Enter your first name">
						    </div> 
					    </div>
					    <div class="col-md-6">
						    <div class="form-group"> 
						        <label class="control-label" for="ptbt_lname">Last Name</label>
						        <input type="text" class="form-control" id="ptbt_lname" name="ptbt_lname" placeholder="Enter your last name">
						    </div> 
					    </div>    
					    <div class="col-md-6">
						    <div class="form-group"> 
						        <label class="control-label" for="email">Email address</label>
						        <input type="email" class="form-control" id="ptbt_email" name="ptbt_email" placeholder="Enter your email"> 
						    </div>
					    </div>
				    </div>'; 
				    
				    // including content in our form html if content is passed to our function
				    if( strlen($content) ): // colon not semi-colon
					    
					    $output .= '<div class="row">
						    <div class="col-md-12">
							    <div class="ptbt-content">'. wpautop($content) .'</div>
						    </div>
					    </div>'; // automatically add p to content that might have line breaks
					    			    
				    endif;
				    
				    // get reward
				    $reward = ptbt_get_list_reward( $list_id );
				    
				    // IF reward exists
					if( $reward !== false ):
					
						// include message about reward
						$output .='
							<div class="ptbt-content ptbt-reward-message alert alert-info">
								<p>Get a FREE DOWNLOAD of <strong>'. $reward['title'] .'</strong> when you join this list!</p>
							</div>
						';
					
					endif;
				    
				    // completing our form html   
				    $output .= '
				    <div class="row">
					    <div class="col-md-12">
						    <button type="submit" name="ptbt_submit" class="btn btn-default btn-lg">Submit</button> 
					    </div>
				    </div>
				</form>
								
			</div>
		';
		
		// return our results/html
		return $output;
	}
	
	
	
	<?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
            <section id="post-<?php the_ID(); ?>" <?php post_class( 'PTpage' ); ?>>
                <h1><?php the_title(); ?></h1>
                <div class="container">
                    <div class="row">
                        <p><?php
                                if ( has_post_thumbnail() ) {
                                    the_post_thumbnail( 'full' );
                                }
                             ?></p>
                        <div class="col-md-8">
                            <?php the_content(); ?>
                            
                            <?php // Display information about countries

								$query = "SELECT * FROM wp_ptbtcountry";
								
								$countries = $wpdb->get_results( $query );
								
								echo '<h3>Countries</h3>';
								echo '<table class="table table-bordered table-hover table-responsive">
									<thead>
										<tr>
											<th>ID</th><th>Region ID</th><th>Country Code</th><th>Name</th>
				                        </tr>
			                        </thead>
			                        <tbody>';
								        foreach ( $countries as $country ) {
									        echo '<tr>
									            <td>'. $country->PTBTCountryId . '</td>
									            <td>' . $country->PTBTRegionId . '</td>
									            <td>' . $country->PTBTCountryCode . '</td>
									            <td>' . $country->PTBTCountryName . '</td>
									        </tr>';
								        }
			                        echo '</tbody></table>';
							 
							 ?>
                        </div>
                    </div>
                    <div class="well">
                        <?php _e( 'page.php', 'pick_the_best_team' ); ?> Some text
                    </div>
                </div>
            </section>
        <?php endwhile; ?>
    <?php else : ?>
        <p><?php _e( 'Sorry, no posts matched your criteria.', 'pick_the_best_team' ); ?></p>
    <?php endif; ?>
	
	
	
	